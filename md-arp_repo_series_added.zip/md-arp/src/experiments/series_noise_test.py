
import argparse, os, numpy as np, pandas as pd
from md_arp.simulator_series import Params, simulate, voltage_input

def noisy_voltage(t, A=1.0, f=1.0, bias=0.0, sigma=0.1):
    base = voltage_input(t, A=A, f=f, bias=bias)
    return base + np.random.normal(0.0, sigma)

if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--T", type=float, default=2.0)
    ap.add_argument("--sigma", type=float, default=0.1)
    ap.add_argument("--out", type=str, default="out/series_noise")
    args = ap.parse_args()
    p = Params()
    arr = simulate(T=args.T, params=p, controller=None, input_fn=noisy_voltage, input_kwargs={"sigma":args.sigma})
    t,i,vC,G,C,L = arr.T
    df = pd.DataFrame({"t":t,"i":i,"vC":vC,"G":G,"C":C,"L":L})
    os.makedirs(args.out, exist_ok=True)
    csv = os.path.join(args.out, "series_noise.csv")
    df.to_csv(csv, index=False)
    print("Saved:", csv)
