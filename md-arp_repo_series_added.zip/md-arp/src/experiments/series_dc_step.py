
import argparse, os, pandas as pd
from md_arp.simulator_series import Params, simulate

def u_dc(t, A=1.0):
    return A

if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--T", type=float, default=3.0)
    ap.add_argument("--A", type=float, default=1.0)
    ap.add_argument("--out", type=str, default="out/series_dc_step")
    args = ap.parse_args()
    p = Params()
    arr = simulate(T=args.T, params=p, controller=None, input_fn=u_dc, input_kwargs={"A":args.A})
    import numpy as np, matplotlib.pyplot as plt
    t,i,vC,G,C,L = arr.T
    df = pd.DataFrame({"t":t,"i":i,"vC":vC,"G":G,"C":C,"L":L})
    os.makedirs(args.out, exist_ok=True)
    csv = os.path.join(args.out, "series_dc_step.csv")
    df.to_csv(csv, index=False)
    print("Saved:", csv)
