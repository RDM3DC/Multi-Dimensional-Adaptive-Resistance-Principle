# Pre-FAB Checklist — LV md-ARP Shunt Filter

**Schematic**
- [ ] Programming header (SWD/JTAG) and labeled UART
- [ ] Hall current sensor within linear range for peak currents
- [ ] Gate driver with desat/OC; proper Miller clamp or series gate resistors
- [ ] TVS at DC input; LC input filter; reverse-polarity protection
- [ ] Snubber footprints at H-bridge; RC across inductor (optional)
- [ ] Separate analog/digital grounds with star-join; Kelvin sense for shunts

**Layout**
- [ ] Tight gate loops; short return paths; switch node kept away from analog
- [ ] Solid ground plane under control; power plane shields high di/dt
- [ ] Thermal vias under FETs/driver; copper pours sized for current
- [ ] Creepage ≥ 1.5 mm across 48 V domains; ≥ 3.0 mm for isolated boundaries
- [ ] Test points on: VIN, 3V3/5V, GATE_H/L, PHASE, SHUNT, UART, SWD

**BOM/Assembly**
- [ ] All parts available (lead times checked); LCSC/house parts where possible
- [ ] Inductor saturation current > 2× peak; low DCR
- [ ] Caps with ≥ 2× voltage derating; temp rating ≥ 105 °C
- [ ] Stencil ordered; paste reduction 30–40% on large pads

**Firmware**
- [ ] Safe defaults (controller disabled on boot)
- [ ] Current limit; watchdog; brown-out
- [ ] Logging enabled (E, G/C/L, errors); config via UART

**Validation Plan**
- [ ] Bring-up steps printed with acceptance criteria
- [ ] PQ tests defined (THD/PF/RMS); data capture pipeline ready
