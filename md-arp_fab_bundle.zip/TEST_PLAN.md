# Test Plan — LV md-ARP Shunt Filter

## 1) Baseline Characterization
- **Loads:** resistive, LED driver emulator, bridge-rectifier + cap (harmonics)
- **Measurements:** THD, PF, RMS current/voltage ripple, inrush (peak & duration)
- **Procedure:** log 60 s windows for each load before md-ARP ON.

## 2) md-ARP Enabled
- Start with low α/μ (convergent region). Run same load windows.
- Record: THD, PF, RMS, md-ARP parameters \(G,C,L\), energy E, controller state.

## 3) Noise Robustness
- Add Gaussian noise (or PWM hash) to the source/load.
- Compare RMS before/after; target ≥ 10–15% reduction.

## 4) Hysteresis (Memory)
- Triangle-like load modulation. Plot (v, i) loop and estimate area (memory strength).

## 5) Edge of Stability
- Increase α/μ toward boundary; watch for onset of oscillations. Back off and log margin.

## 6) Thermal/EMI
- 10–15 min soak at nominal; capture temp map and any EMI notes (sniffer probe).

## Data to Save
- CSV logs (v, i, G, C, L, E, loop errors), summary JSON per run, scope screenshots.
