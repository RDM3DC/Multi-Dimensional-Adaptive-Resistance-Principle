# LV Shunt Active Filter — FAB README (md-arp)

This pack captures the **manufacturing settings**, **assembly notes**, and **DFM tips** for the low-voltage (24–48 V) md-ARP shunt filter prototype.

## Target
- **Function**: Shunt active power-quality (PQ) filter implementing md-ARP (adaptive G/C/L) + meta-controller
- **Bus**: 24–48 V (isolated bench supply)
- **Switching**: MOSFET full-bridge, current injection via inductor (≈200–500 µH)
- **Controller**: MCU with fast ADC + PWM

## PCB Manufacturing Spec (recommended)
- **Layers**: 4-layer (preferred), 1 oz outer, 0.5 oz inner; 1.6 mm FR-4, Tg ≥ 170 °C
- **Stack** (top→bottom): Signal / GND plane / PWR plane / Signal
- **Finish**: ENIG (good for test pads & low-resistance contacts)
- **Soldermask**: any (green default)
- **Silkscreen**: top/bottom
- **Solder stencil**: YES (0.12–0.13 mm), nano-coated preferred
- **Min trace/space**: 6/6 mil OK (use 8/8 where high di/dt)
- **Via**: tented vias; thermal via arrays under FETs and drivers
- **Creepage**: ≥ 1.5 mm across 48 V domains; ≥ 3.0 mm across any reinforced isolation boundary

## Assembly Notes
- Prefer turnkey assembly (JLC/PCBWay) with **basic library** parts where possible.
- Hand-place niche parts (Hall sensor, inductor, connectors) and any long-lead items.
- Include **programming header** (SWD/JTAG) + **UART** for logs.
- Heatsink/thermal pad under FETs; paste mask windowing 60–70% to control voids.
- Place **snubber footprints** (RC/TVS) at the bridge; keep **gate loops** tight; add **series gate resistors** (5–15 Ω).
- Kelvin sense for shunts; star ground between power and control planes; avoid analog/digital ground loops.

## Manufacturing Outputs (what the fab/assembler needs)
- **Gerbers** + **NC drill** + **FAB drawing** (stackup, finished copper, mask, impedance not required)
- **Pick-and-Place** (XYRS) with rotation reference
- **BOM** (MPN, footprint, voltage/temp ratings, supplier SKU)
- **Assembly notes** (do-not-stuff, alt parts, polarity, torque specs for terminals)
- **3D step** (optional but helpful)

## Panelization
- 2–5 up per panel; 2 mm rails with tooling holes and fiducials.
- Mouse-bites or V-groove per assembler preference.

## ESD/EMI
- TVS at supply input, LC input filter ahead of bridge, MOV optional for LV bench.
- Keep high di/dt loops compact; route return under switch nodes on GND plane.
- Add common-mode choke footprints at I/O connectors (optional).

## Labels
- Board rev, date code, polarity markers, test point IDs, SWD pinout on silk.
