# LV Shunt Filter — Bring-Up Guide (md-arp)

**Purpose:** power-on safely, validate rails and signals, then close loops incrementally.

## Equipment
- Isolated bench supply (24–48 V), current-limited
- DMM, oscilloscope (≥ 100 MHz), differential probe or isolated scope
- Electronic load / dummy loads
- Signal generator (optional), logic probe/USB-UART
- Thermal cam or thermocouples

## Steps
1. **Visual & Continuity**
   - No shorts across supply rails; polarity correct; heatsinks installed.
2. **Standby Power**
   - Power the control rails only (if split). Verify 3.3 V/5 V rails in spec. Check MCU boots (blinky).
3. **Programming & Telemetry**
   - Flash minimal FW: UART prints heartbeat + ADC readings. Confirm ADC noise, offsets.
4. **PWM Dry Run**
   - Enable PWM at low duty with **bridge disconnected** from inductor (or with dummy R). Verify gate signals, dead-time, no shoot-through.
5. **Sensor Calibration**
   - Zero Hall offset; verify linearity with small known currents.
6. **Attach Inductor / Shunt Stage**
   - Start at **low bus voltage** (e.g., 12 V). Observe current waveforms at light load.
7. **Close Inner Current Loop**
   - PI loop only; track a small sinusoidal reference. Verify stability margins (no audible/visible oscillation).
8. **Enable md-ARP (slow)**
   - Update G/C/L slowly (low α/μ). Verify parameters remain bounded; log \(E=0.5Cv^2+0.5Li^2\).
9. **Meta-Controller On**
   - Enable energy target \(E^*\). Step through load cases; maintain convergence (no runaway, clean current tracking).
10. **PQ Tests**
    - Inject harmonic load (rectifier/LED driver emulator). Measure **THD ↓**, **PF ↑**, **RMS ripple ↓** vs baseline.
11. **Thermals & EMI**
    - ≥ 10 minutes at nominal. No hot spots > 70 °C; sniff with near-field probe if available.
12. **Faults**
    - Hard OC, desat, over-temp shutoff verified.

## Pass Criteria (initial)
- THD ↓ ≥ 10–20%, PF ↑ ≥ 0.05, RMS noise ↓ ≥ 10–15%
- λ_max (from sim for same gains) < 0; no limit-cycle behavior in hardware
- No component > 70 °C at nominal current; no audible instability
